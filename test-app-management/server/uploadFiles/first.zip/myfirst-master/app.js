//app.js
App({
  onLaunch: function () {
    
  },
  globalData: {
    userInfo: null,
    host: 'http://localhost:5000',
  }
})