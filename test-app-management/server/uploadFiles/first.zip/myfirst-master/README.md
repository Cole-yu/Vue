# 慕课网《入门微信小程序开发》示例代码
> 地址：https://www.imooc.com/learn/974
>
> 为了方便各位同学拿到视频中的素材, 连胜老师特意把视频中的示例代码分享给大家~

## 本代码只供学员学习使用，请勿用于其他商业用途。

## 想添加小程序技术群，可以添加下方小助手
![Alt text](http://demos.pxuexiao.com/web_css/img/xigua_net.jpeg)
